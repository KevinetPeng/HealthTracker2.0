The JSON files for comment and number data are sample data
files for showcase only.

If you would like to erase the data, please open 
"commentData.json" and "heathNumData.json" with a text 
editor and delete the data inside. Don't delete the entire
file.